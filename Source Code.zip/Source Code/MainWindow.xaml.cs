﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace SortingVisualizer
{
    public partial class MainWindow : Window
    {
        private int[] _array;
        private readonly Random _random = new Random();
        private int _arraySize = 50;
        private bool _isSorting;
        private bool _playSound = false;
        private SignalGenerator _signalGenerator;
        private WaveOutEvent _waveOut;

        public MainWindow()
        {
            InitializeComponent();
            SetupAudio();
            ResetArray();
            LinesSlider.ValueChanged += LinesSlider_ValueChanged;
        }

        private void SetupAudio()
        {
            _signalGenerator = new SignalGenerator()
            {
                Gain = 0.2,
                Frequency = 440.0,
                Type = SignalGeneratorType.Sin
            };

            _waveOut = new WaveOutEvent();
            _waveOut.Init(_signalGenerator);
            _waveOut.Play();
        }

        private void ResetArray()
        {
            _array = new int[_arraySize];
            for (int i = 0; i < _arraySize; i++)
            {
                _array[i] = _random.Next(10, 400);
            }
            DrawArray();
        }

        private void DrawArray(int highlightIndex = -1)
        {
            SortingCanvas.Children.Clear();
            double barWidth = SortingCanvas.ActualWidth / _arraySize;
            for (int i = 0; i < _arraySize; i++)
            {
                var bar = new Rectangle
                {
                    Height = _array[i],
                    Width = barWidth,
                    Fill = i == highlightIndex ? Brushes.Red : Brushes.White
                };
                Canvas.SetLeft(bar, i * barWidth);
                Canvas.SetBottom(bar, 0);
                SortingCanvas.Children.Add(bar);
            }
        }

        private async void RunButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isSorting) return;
            _isSorting = true;

            string selectedSort = ((ComboBoxItem)SortComboBox.SelectedItem)?.Content.ToString();
            switch (selectedSort)
            {
                case "Bubble Sort":
                    await BubbleSort();
                    break;
                case "Quick Sort":
                    await QuickSort(0, _array.Length - 1);
                    break;
                case "Insertion Sort":
                    await InsertionSort();
                    break;
                case "Selection Sort":
                    await SelectionSort();
                    break;
                case "Merge Sort":
                    await MergeSort(0, _array.Length - 1);
                    break;
                case "Heap Sort":
                    await HeapSort();
                    break;
                case "Radix Sort":
                    await RadixSort();
                    break;
                case "Shell Sort":
                    await ShellSort();
                    break;
                case "Counting Sort":
                    await CountingSort();
                    break;
                case "Cocktail Sort":
                    await CocktailSort();
                    break;
                case "Comb Sort":
                    await CombSort();
                    break;
                case "Gnome Sort":
                    await GnomeSort();
                    break;
            }

            _isSorting = false;
        }

        private void StopButton_Click(object sender, RoutedEventArgs e)
        {
            _isSorting = false;
        }

        private void HideToolBarButton_Click(object sender, RoutedEventArgs e)
        {
            ToolBarTray.Visibility = Visibility.Collapsed;
            ShowToolBarButton.Visibility = Visibility.Visible;
        }

        private void ShowToolBarButton_Click(object sender, RoutedEventArgs e)
        {
            ToolBarTray.Visibility = Visibility.Visible;
            ShowToolBarButton.Visibility = Visibility.Collapsed;
        }

        private void LinesSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            _arraySize = (int)LinesSlider.Value;
            ResetArray();
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            ResetArray();
        }

        private void SoundButton_Click(object sender, RoutedEventArgs e)
        {
            _playSound = !_playSound;
            SoundButton.Content = _playSound ? "Sound: On" : "Sound: Off";
            if (!_playSound)
            {
                _waveOut.Stop();
            }
            else
            {
                _waveOut.Play();
            }
        }

        private void PlaySound(int value)
        {
            if (_playSound)
            {
                double frequency = 200 + (value * 2); // Adjust scaling as needed
                _signalGenerator.Frequency = frequency;
            }
        }

        private async Task BubbleSort()
        {
            for (int i = 0; i < _array.Length - 1; i++)
            {
                for (int j = 0; j < _array.Length - i - 1; j++)
                {
                    if (_array[j] > _array[j + 1])
                    {
                        int temp = _array[j];
                        _array[j] = _array[j + 1];
                        _array[j + 1] = temp;
                        DrawArray(j + 1);
                        PlaySound(_array[j + 1]);
                        await Task.Delay((int)(101 - SpeedSlider.Value));
                        if (!_isSorting) return;
                    }
                }
            }
        }

        private async Task QuickSort(int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(low, high);
                DrawArray(pi);
                PlaySound(_array[pi]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
                await QuickSort(low, pi - 1);
                if (!_isSorting) return;
                await QuickSort(pi + 1, high);
            }
        }

        private int Partition(int low, int high)
        {
            int pivot = _array[high];
            int i = (low - 1);
            for (int j = low; j < high; j++)
            {
                if (_array[j] < pivot)
                {
                    i++;
                    int temp = _array[i];
                    _array[i] = _array[j];
                    _array[j] = temp;
                    DrawArray(j);
                    PlaySound(_array[j]);
                    if (!_isSorting) return high;
                }
            }
            int temp1 = _array[i + 1];
            _array[i + 1] = _array[high];
            _array[high] = temp1;
            return i + 1;
        }

        private async Task InsertionSort()
        {
            for (int i = 1; i < _array.Length; i++)
            {
                int key = _array[i];
                int j = i - 1;
                while (j >= 0 && _array[j] > key)
                {
                    _array[j + 1] = _array[j];
                    j--;
                    DrawArray(j + 1);
                    PlaySound(_array[j + 1]);
                    await Task.Delay((int)(101 - SpeedSlider.Value));
                    if (!_isSorting) return;
                }
                _array[j + 1] = key;
                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
            }
        }

        private async Task SelectionSort()
        {
            for (int i = 0; i < _array.Length - 1; i++)
            {
                int minIndex = i;
                for (int j = i + 1; j < _array.Length; j++)
                {
                    if (_array[j] < _array[minIndex])
                    {
                        minIndex = j;
                    }
                }
                int temp = _array[minIndex];
                _array[minIndex] = _array[i];
                _array[i] = temp;
                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
            }
        }

        private async Task MergeSort(int left, int right)
        {
            if (left < right)
            {
                int mid = (left + right) / 2;
                await MergeSort(left, mid);
                await MergeSort(mid + 1, right);
                await Merge(left, mid, right);
            }
        }

        private async Task Merge(int left, int mid, int right)
        {
            int n1 = mid - left + 1;
            int n2 = right - mid;

            int[] leftArray = new int[n1];
            int[] rightArray = new int[n2];

            for (int i = 0; i < n1; ++i)
                leftArray[i] = _array[left + i];
            for (int j = 0; j < n2; ++j)
                rightArray[j] = _array[mid + 1 + j];

            int i1 = 0, j1 = 0;
            int k = left;
            while (i1 < n1 && j1 < n2)
            {
                if (leftArray[i1] <= rightArray[j1])
                {
                    _array[k] = leftArray[i1];
                    i1++;
                }
                else
                {
                    _array[k] = rightArray[j1];
                    j1++;
                }
                DrawArray(k);
                PlaySound(_array[k]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
                k++;
            }

            while (i1 < n1)
            {
                _array[k] = leftArray[i1];
                i1++;
                DrawArray(k);
                PlaySound(_array[k]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
                k++;
            }

            while (j1 < n2)
            {
                _array[k] = rightArray[j1];
                j1++;
                DrawArray(k);
                PlaySound(_array[k]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
                k++;
            }
        }

        private async Task HeapSort()
        {
            int n = _array.Length;

            for (int i = n / 2 - 1; i >= 0; i--)
                await Heapify(n, i);

            for (int i = n - 1; i > 0; i--)
            {
                int temp = _array[0];
                _array[0] = _array[i];
                _array[i] = temp;

                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;

                await Heapify(i, 0);
            }
        }

        private async Task Heapify(int n, int i)
        {
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < n && _array[left] > _array[largest])
                largest = left;

            if (right < n && _array[right] > _array[largest])
                largest = right;

            if (largest != i)
            {
                int swap = _array[i];
                _array[i] = _array[largest];
                _array[largest] = swap;

                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;

                await Heapify(n, largest);
            }
        }

        private async Task RadixSort()
        {
            int m = GetMax(_array, _array.Length);

            for (int exp = 1; m / exp > 0; exp *= 10)
                await CountSort(exp);
        }

        private int GetMax(int[] arr, int n)
        {
            int mx = arr[0];
            for (int i = 1; i < n; i++)
                if (arr[i] > mx)
                    mx = arr[i];
            return mx;
        }

        private async Task CountSort(int exp)
        {
            int n = _array.Length;
            int[] output = new int[n];
            int[] count = new int[10];

            for (int i = 0; i < n; i++)
                count[(_array[i] / exp) % 10]++;

            for (int i = 1; i < 10; i++)
                count[i] += count[i - 1];

            for (int i = n - 1; i >= 0; i--)
            {
                output[count[(_array[i] / exp) % 10] - 1] = _array[i];
                count[(_array[i] / exp) % 10]--;
            }

            for (int i = 0; i < n; i++)
            {
                _array[i] = output[i];
                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
            }
        }

        private async Task ShellSort()
        {
            int n = _array.Length;
            for (int gap = n / 2; gap > 0; gap /= 2)
            {
                for (int i = gap; i < n; i += 1)
                {
                    int temp = _array[i];
                    int j;
                    for (j = i; j >= gap && _array[j - gap] > temp; j -= gap)
                    {
                        _array[j] = _array[j - gap];
                        DrawArray(j);
                        PlaySound(_array[j]);
                        await Task.Delay((int)(101 - SpeedSlider.Value));
                        if (!_isSorting) return;
                    }
                    _array[j] = temp;
                }
            }
        }

        private async Task CountingSort()
        {
            int max = _array.Max();
            int min = _array.Min();
            int range = max - min + 1;

            int[] count = new int[range];
            int[] output = new int[_array.Length];

            for (int i = 0; i < _array.Length; i++)
                count[_array[i] - min]++;

            for (int i = 1; i < count.Length; i++)
                count[i] += count[i - 1];

            for (int i = _array.Length - 1; i >= 0; i--)
            {
                output[count[_array[i] - min] - 1] = _array[i];
                count[_array[i] - min]--;
            }

            for (int i = 0; i < _array.Length; i++)
            {
                _array[i] = output[i];
                DrawArray(i);
                PlaySound(_array[i]);
                await Task.Delay((int)(101 - SpeedSlider.Value));
                if (!_isSorting) return;
            }
        }

        private async Task CocktailSort()
        {
            bool swapped = true;
            int start = 0;
            int end = _array.Length;

            while (swapped)
            {
                swapped = false;

                for (int i = start; i < end - 1; ++i)
                {
                    if (_array[i] > _array[i + 1])
                    {
                        int temp = _array[i];
                        _array[i] = _array[i + 1];
                        _array[i + 1] = temp;
                        DrawArray(i);
                        PlaySound(_array[i]);
                        await Task.Delay((int)(101 - SpeedSlider.Value));
                        if (!_isSorting) return;
                        swapped = true;
                    }
                }

                if (!swapped)
                    break;

                swapped = false;
                end--;

                for (int i = end - 1; i >= start; i--)
                {
                    if (_array[i] > _array[i + 1])
                    {
                        int temp = _array[i];
                        _array[i] = _array[i + 1];
                        _array[i + 1] = temp;
                        DrawArray(i);
                        PlaySound(_array[i]);
                        await Task.Delay((int)(101 - SpeedSlider.Value));
                        if (!_isSorting) return;
                        swapped = true;
                    }
                }

                start++;
            }
        }

        private async Task CombSort()
        {
            int n = _array.Length;

            int gap = n;
            bool swapped = true;

            while (gap != 1 || swapped)
            {
                gap = GetNextGap(gap);
                swapped = false;

                for (int i = 0; i < n - gap; i++)
                {
                    if (_array[i] > _array[i + gap])
                    {
                        int temp = _array[i];
                        _array[i] = _array[i + gap];
                        _array[i + gap] = temp;
                        DrawArray(i);
                        PlaySound(_array[i]);
                        await Task.Delay((int)(101 - SpeedSlider.Value));
                        if (!_isSorting) return;
                        swapped = true;
                    }
                }
            }
        }

        private int GetNextGap(int gap)
        {
            gap = (gap * 10) / 13;
            if (gap < 1)
                return 1;
            return gap;
        }

        private async Task GnomeSort()
        {
            int index = 0;

            while (index < _array.Length)
            {
                if (index == 0)
                    index++;
                if (_array[index] >= _array[index - 1])
                    index++;
                else
                {
                    int temp = _array[index];
                    _array[index] = _array[index - 1];
                    _array[index - 1] = temp;
                    index--;
                    DrawArray(index);
                    PlaySound(_array[index]);
                    await Task.Delay((int)(101 - SpeedSlider.Value));
                    if (!_isSorting) return;
                }
            }
        }
    }
}
